#!/bin/bash

# Take input parameter as archive name 
archive_name=$1

# Compress files into tar.gz archive
tar -czf $archive_name.tar.gz *